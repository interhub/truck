export const START = 'START'
export const INFO = 'INFO'
export const FEED = 'FEED'
export const CUP = 'CUP'
export const ORDER_CAR = 'ORDER_CAR'
export const ORDER_PEOPLE = 'ORDER_PEOPLE'
export const ITOG = 'ITOG'
export const LIST = 'LIST'






