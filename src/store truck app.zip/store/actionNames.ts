export const SET_MENU = 'SET_MENU'
export const SET_SCREEN = 'SET_SCREEN'
export const SET_LOADER = 'SET_LOADER'
export const SET_ORDER = 'SET_ORDER'
export const SET_USER = 'SET_USER'
export const SET_SALE = 'SET_SALE'
export const SET_ORDERS = 'SET_ORDERS'


